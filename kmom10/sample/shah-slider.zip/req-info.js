var speedReq = 3000; 
var effectOfAnimation = "animate";